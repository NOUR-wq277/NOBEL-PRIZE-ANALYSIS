![صورة توضيحية](Nobel_Prize.png)

# import important librarys 


```python
import pandas as pd 
import numpy as  np 
import matplotlib.pyplot as plt 
import seaborn as sns 
```

# inspect data 


```python
Nopel=pd.read_csv('nobel.csv')
print(Nopel.info())
print("="*50)
print(Nopel.describe())
print("="*50)
print(Nopel.describe(include='object'))
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1000 entries, 0 to 999
    Data columns (total 18 columns):
     #   Column                Non-Null Count  Dtype 
    ---  ------                --------------  ----- 
     0   year                  1000 non-null   int64 
     1   category              1000 non-null   object
     2   prize                 1000 non-null   object
     3   motivation            912 non-null    object
     4   prize_share           1000 non-null   object
     5   laureate_id           1000 non-null   int64 
     6   laureate_type         1000 non-null   object
     7   full_name             1000 non-null   object
     8   birth_date            968 non-null    object
     9   birth_city            964 non-null    object
     10  birth_country         969 non-null    object
     11  sex                   970 non-null    object
     12  organization_name     736 non-null    object
     13  organization_city     735 non-null    object
     14  organization_country  735 non-null    object
     15  death_date            596 non-null    object
     16  death_city            579 non-null    object
     17  death_country         585 non-null    object
    dtypes: int64(2), object(16)
    memory usage: 140.8+ KB
    None
    ==================================================
                  year  laureate_id
    count  1000.000000  1000.000000
    mean   1973.721000   509.099000
    std      34.523195   298.130617
    min    1901.000000     1.000000
    25%    1949.750000   250.750000
    50%    1979.000000   500.500000
    75%    2003.000000   764.250000
    max    2023.000000  1034.000000
    ==================================================
            category                              prize  \
    count       1000                               1000   
    unique         6                                621   
    top     Medicine  The Nobel Prize in Chemistry 1972   
    freq         227                                  3   
    
                                                   motivation prize_share  \
    count                                                 912        1000   
    unique                                                615           4   
    top     "for their studies of extremely fast chemical ...       1-Jan   
    freq                                                    3         358   
    
           laureate_type                                          full_name  \
    count           1000                                               1000   
    unique             2                                                993   
    top       Individual  Comité international de la Croix Rouge (Intern...   
    freq             966                                                  3   
    
            birth_date    birth_city             birth_country   sex  \
    count          968           964                       969   970   
    unique         949           649                       129     2   
    top     10/24/1932  New York, NY  United States of America  Male   
    freq             2            55                       291   905   
    
                   organization_name organization_city      organization_country  \
    count                        736               735                       735   
    unique                       325               195                        29   
    top     University of California     Cambridge, MA  United States of America   
    freq                          36                53                       385   
    
            death_date death_city             death_country  
    count          596        579                       585  
    unique         585        293                        50  
    top     11/19/2013      Paris  United States of America  
    freq             2         27                       206  
    

# The percentage of missing values ​​in the columns


```python
print(Nopel.isnull().mean()*100)
```

    year                     0.0
    category                 0.0
    prize                    0.0
    motivation               8.8
    prize_share              0.0
    laureate_id              0.0
    laureate_type            0.0
    full_name                0.0
    birth_date               3.2
    birth_city               3.6
    birth_country            3.1
    sex                      3.0
    organization_name       26.4
    organization_city       26.5
    organization_country    26.5
    death_date              40.4
    death_city              42.1
    death_country           41.5
    dtype: float64
    

# Clean Data


```python
col_to_fill= ["motivation", "birth_date", "birth_city", "birth_country",
                        "organization_name", "organization_city", "organization_country",
                        "death_date", "death_city", "death_country","sex"]
# reblace every null to most Most frequent
for col in col_to_fill:
    Nopel[col].fillna(Nopel[col].mode()[0],inplace=True)
print(Nopel.isnull().sum())
```

    year                    0
    category                0
    prize                   0
    motivation              0
    prize_share             0
    laureate_id             0
    laureate_type           0
    full_name               0
    birth_date              0
    birth_city              0
    birth_country           0
    sex                     0
    organization_name       0
    organization_city       0
    organization_country    0
    death_date              0
    death_city              0
    death_country           0
    dtype: int64
    

    C:\Users\user\AppData\Local\Temp\ipykernel_16568\3713457160.py:6: FutureWarning: A value is trying to be set on a copy of a DataFrame or Series through chained assignment using an inplace method.
    The behavior will change in pandas 3.0. This inplace method will never work because the intermediate object on which we are setting values always behaves as a copy.
    
    For example, when doing 'df[col].method(value, inplace=True)', try using 'df.method({col: value}, inplace=True)' or df[col] = df[col].method(value) instead, to perform the operation inplace on the original object.
    
    
      Nopel[col].fillna(Nopel[col].mode()[0],inplace=True)
    

# Number of awards awarded for each category


```python
Nopel['n_of_category'] = Nopel['category'].map(Nopel['category'].value_counts())
sns.despine()
sns.set_style=("whitegrid")
sns.set_palette("husl")
sns.set_context("notebook")
g=sns.catplot(x='category',y='n_of_category',data=Nopel,kind="bar",col='sex',hue="sex")
g.set_xticklabels(rotation=45,fontweight='bold')
g.fig.suptitle("CATEGORY",y=1.03)
g.set_titles("COUNT OF CATEGORY OF {col_name}")
g._legend.set_loc("upper right")
g._legend.set_frame_on(True)
g.legend.get_frame().set_edgecolor("Black")
plt.show()
```


    <Figure size 640x480 with 0 Axes>



    
![png](output_10_1.png)
    


# Which countries have won the largest number of Nobel Prizes


```python
top_countries=Nopel["birth_country"].head(10) 
g=sns.catplot(x="category", y="n_of_category",hue="category", data=Nopel,kind="bar", palette="coolwarm", errorbar=None,aspect=1.5,height=6)
plt.xticks(rotation=30, ha="right", fontsize=12, fontweight="bold",color="red")
sns.despine()
plt.title("Countries")
plt.show()
```


    
![png](output_12_0.png)
    


# Analysis of the development of awards after 2020


```python
filter_data=Nopel[Nopel['year']>2020]
g=sns.relplot(data=Nopel, x=filter_data['year'],y=filter_data['category'],kind='line',hue='sex',style='sex',aspect=1.5,height=6,markers=True,palette={"Male":"red","Female":"black"})
plt.xticks(rotation=30, ha="right", fontsize=12, fontweight="bold",color="red")
plt.yticks(rotation=30, ha="right", fontsize=12, fontweight="bold",color="black")
sns.despine()
g._legend.set_loc("upper right")
g._legend.set_frame_on(True)
g.legend.get_frame().set_edgecolor("Black")
plt.grid(True, linestyle="--", alpha=0.5)
plt.xlabel("Year", fontsize=14, fontweight="bold", color="black")
plt.ylabel("Category", fontsize=14, fontweight="bold", color="black")
plt.show()
```


    
![png](output_14_0.png)
    



# What is the most commonly awarded gender and birth country


```python
sns.despine()
palette_COLOR = ["darkred", "indigo"]
g=sns.catplot(x='sex',data=Nopel,kind="count",hue="sex",aspect=2,height=10,palette=palette_COLOR)
g.set_xticklabels(rotation=45,fontweight='bold')
plt.title("Distribution of Nobel Prize Winners by Gender", fontsize=30, fontweight='bold')
plt.show()

```


    <Figure size 640x480 with 0 Axes>



    
![png](output_16_1.png)
    



```python

```

# Which decade had the highest ratio of US-born Nobel Prize winners to total winners in all categories


```python

Nopel['Decade'] = (Nopel['year'] // 10) * 10  
usa_winners =Nopel[Nopel['birth_country'] == 'United States of America']

usa_decade_counts = usa_winners.groupby('Decade').size().reset_index(name='USA Winners')

total_decade_counts = Nopel.groupby('Decade').size().reset_index(name='Total Winners')
decade_comparison = pd.merge(total_decade_counts, usa_decade_counts, on='Decade', how='left')

decade_comparison['USA Ratio'] = decade_comparison['USA Winners'] / decade_comparison['Total Winners']


plt.figure(figsize=(10, 6))
sns.barplot(x='Decade', y='USA Ratio', data=decade_comparison, palette='Blues')
plt.title('Ratio of US Nobel Prize Winners by Decade')
plt.ylabel('USA Winners Ratio')
plt.xlabel('Decade')
plt.xticks(rotation=45)
plt.show()

```

    C:\Users\user\AppData\Local\Temp\ipykernel_16568\2569371931.py:13: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x='Decade', y='USA Ratio', data=decade_comparison, palette='Blues')
    


    
![png](output_19_1.png)
    


# decade Nobel Prize category combination had the highest proportion of female laureates 


```python
women_win=Nopel[Nopel['sex']=="Female"]
sns.catplot(x='Decade',data=women_win,kind="count",aspect=2,height=10)
plt.xticks(rotation=45, fontsize=24)
plt.yticks(fontsize=24)
plt.xlabel("Decade", fontsize=14)
plt.ylabel("Count of Female Winners", fontsize=14)
plt.title("Nobel Prize Female Winners by Decade", fontsize=16, fontweight="bold")
sns.set_context("poster")
plt.show()
```


    
![png](output_21_0.png)
    


#  scientists who have won more than one Nobel Prize


```python
repeat_list=[]
Names=Nopel['full_name'].value_counts()
Names=dict(Names)
Names
for name,num in Names.items():
    if Names[name]>1:
        repeat_list.append(name)
for i in repeat_list:
    print(f"scientist name is  ({i})")
```

    scientist name is  (Comité international de la Croix Rouge (International Committee of the Red Cross))
    scientist name is  (Linus Carl Pauling)
    scientist name is  (John Bardeen)
    scientist name is  (Frederick Sanger)
    scientist name is  (Marie Curie, née Sklodowska)
    scientist name is  (Office of the United Nations High Commissioner for Refugees (UNHCR))
    
